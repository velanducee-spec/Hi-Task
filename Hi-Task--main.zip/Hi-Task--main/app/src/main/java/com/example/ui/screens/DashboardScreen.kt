package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.LockClock
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.RemoteConfigData
import com.example.data.models.SpinRecordEntity
import com.example.data.models.UserEntity
import com.example.repository.HiTaskRepository
import com.example.ui.components.AdBannerView
import com.example.ui.components.NativeAdCard
import com.example.ui.theme.*
import kotlinx.coroutines.delay

@Composable
fun DashboardScreen(
    user: UserEntity,
    config: RemoteConfigData,
    lastChestClaimTime: Long,
    onClaimChest: () -> Unit,
    chestCooldownMsg: String?,
    isSpinning: Boolean,
    onSpinRequested: () -> Unit,
    lastSpinResult: SpinRecordEntity?,
    onClearSpinResult: () -> Unit,
    onTapCoin: () -> Unit,
    tapMsg: String?
) {
    var currentTime by remember { mutableLongStateOf(System.currentTimeMillis()) }

    LaunchedEffect(Unit) {
        while (true) {
            delay(1000L)
            currentTime = System.currentTimeMillis()
        }
    }

    val cooldownMs = config.chestCooldownSeconds * 1000L
    val elapsedMs = currentTime - lastChestClaimTime
    val isChestAvailable = lastChestClaimTime == 0L || elapsedMs >= cooldownMs
    val remainingSec = if (isChestAvailable) 0L else (cooldownMs - elapsedMs) / 1000L

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    Image(
                        painter = painterResource(id = com.example.R.drawable.hi_task_hero_banner_1785521016126),
                        contentDescription = "Hi-Task Banner",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.horizontalGradient(
                                    colors = listOf(
                                        DarkBackground.copy(alpha = 0.85f),
                                        Color.Transparent
                                    )
                                )
                            )
                    )
                    Column(
                        modifier = Modifier
                            .align(Alignment.CenterStart)
                            .padding(20.dp)
                    ) {
                        Text(
                            text = "EARN REWARDS DAILY",
                            style = MaterialTheme.typography.labelMedium.copy(
                                color = GoldPrimary,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 1.sp
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "Spin, Claim Chest & Tap",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.ExtraBold,
                                color = TextPrimary
                            )
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "1000 Coins = \$0.50 USD • Minimum \$10 Payout",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )
                    }
                }
            }
        }

        // Ad Banner View
        item {
            AdBannerView()
        }

        // Golden Chest Section
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("golden_chest_card")
            ) {
                Column(
                    modifier = Modifier.padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(GoldPrimary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CardGiftcard,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Golden Chest",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "Claim every 5 minutes (300s)",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                )
                            }
                        }

                        Surface(
                            color = if (isChestAvailable) EmeraldGreen.copy(alpha = 0.2f) else DarkSurfaceVariant,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(
                                    imageVector = if (isChestAvailable) Icons.Default.FlashOn else Icons.Default.LockClock,
                                    contentDescription = null,
                                    tint = if (isChestAvailable) EmeraldGreen else GoldPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isChestAvailable) "READY" else "${remainingSec / 60}m ${remainingSec % 60}s",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isChestAvailable) EmeraldGreen else GoldPrimary
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Grants 20 to 50 Coins instantly upon opening.",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )

                    if (chestCooldownMsg != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = chestCooldownMsg,
                            color = RoseRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = onClaimChest,
                        enabled = isChestAvailable,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = GoldPrimary,
                            disabledContainerColor = DarkSurfaceVariant
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("claim_golden_chest_button")
                    ) {
                        Text(
                            text = if (isChestAvailable) "Open Golden Chest (+Coins)" else "Cooldown Active (${remainingSec}s)",
                            color = if (isChestAvailable) Color.Black else TextDisabled,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // Spin Wheel Section
        item {
            SpinWheelView(
                sections = config.spinSections,
                isSpinning = isSpinning,
                onSpinRequested = onSpinRequested,
                lastSpinResult = lastSpinResult,
                onClearResultDialog = onClearSpinResult
            )
        }

        // Tap-to-Earn Section
        item {
            var tapScale by remember { mutableFloatStateOf(1f) }

            LaunchedEffect(tapScale) {
                if (tapScale != 1f) {
                    delay(100L)
                    tapScale = 1f
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.3f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tap_to_earn_card")
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NeonCyan.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.TouchApp,
                                    contentDescription = null,
                                    tint = NeonCyan,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Tap-to-Earn",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "Limit: ${config.tapsPerMinuteLimit} Taps/Min • ${config.coinPerTap} Coin/Tap",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                )
                            }
                        }

                        Surface(
                            color = NeonCyan.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text(
                                text = "RATE LIMITED",
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = NeonCyan,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    // Animated Tap Button
                    Box(
                        modifier = Modifier
                            .size(100.dp)
                            .scale(tapScale)
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = listOf(
                                        GoldPrimary,
                                        GoldSecondary,
                                        AmberAccent
                                    )
                                )
                            )
                            .clickable {
                                tapScale = 1.15f
                                onTapCoin()
                            }
                            .testTag("tap_coin_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.TouchApp,
                                contentDescription = "Tap",
                                tint = Color.Black,
                                modifier = Modifier.size(36.dp)
                            )
                            Text(
                                text = "TAP ME!",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.Black
                            )
                        }
                    }

                    if (tapMsg != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = tapMsg,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (tapMsg.contains("Limit")) RoseRed else EmeraldGreen
                        )
                    }
                }
            }
        }

        // Native Ad Card
        item {
            NativeAdCard()
        }
    }
}
