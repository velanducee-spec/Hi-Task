package com.example.config

import org.json.JSONArray
import org.json.JSONObject

data class SpinSectionConfig(
    val coins: Int,
    val weight: Int
)

data class RemoteConfigData(
    val requireInternet: Boolean = true,
    val minWithdrawalUsd: Double = 10.00,
    val coinConversionRate: Double = 0.0005, // 1000 coins = $0.50 -> 1 coin = $0.0005
    val perAdUserEarningUsd: Double = 0.000005,
    val referralRewardUsd: Double = 0.025,
    val referralPendingToAvailableSeconds: Long = 1800L,
    val requiredCompletedReferralsToUnlockWithdrawals: Int = 2,
    
    // Chest
    val chestCooldownSeconds: Long = 300L,
    val chestRequiresAd: Boolean = false,
    val chestRewardsCoins: List<Int> = listOf(20, 35, 50),
    
    // Spin wheel
    val spinSections: List<SpinSectionConfig> = listOf(
        SpinSectionConfig(50, 300),
        SpinSectionConfig(120, 250),
        SpinSectionConfig(300, 100),
        SpinSectionConfig(100, 200),
        SpinSectionConfig(70, 149),
        SpinSectionConfig(500, 1)
    ),
    val spinRequiresAd: Boolean = true,
    val maxSpinsPerHour: Int = 12,
    
    // Tap
    val coinPerTap: Int = 1,
    val tapsPerMinuteLimit: Int = 60,
    
    // Economy
    val dailyCoinCap: Long = 20000L,
    val monthlyCoinCap: Long = 500000L
) {
    fun toJsonString(): String {
        val root = JSONObject()
        val appObj = JSONObject()
        appObj.put("require_internet", requireInternet)
        appObj.put("min_withdrawal_usd", minWithdrawalUsd)
        
        val coinToUsdObj = JSONObject()
        coinToUsdObj.put("coins", 1000)
        coinToUsdObj.put("usd", 0.50)
        appObj.put("coin_to_usd", coinToUsdObj)
        appObj.put("per_ad_user_earning_usd", perAdUserEarningUsd)
        
        val refObj = JSONObject()
        refObj.put("reward_usd", referralRewardUsd)
        refObj.put("pending_to_available_seconds", referralPendingToAvailableSeconds)
        refObj.put("required_completed_referrals_to_unlock_withdrawals", requiredCompletedReferralsToUnlockWithdrawals)
        appObj.put("referral", refObj)
        root.put("app", appObj)
        
        val featObj = JSONObject()
        val chestObj = JSONObject()
        chestObj.put("cooldown_seconds", chestCooldownSeconds)
        chestObj.put("requires_ad_to_claim", chestRequiresAd)
        val chestArr = JSONArray()
        chestRewardsCoins.forEach { chestArr.put(it) }
        chestObj.put("default_rewards_coins", chestArr)
        featObj.put("golden_chest", chestObj)
        
        val spinObj = JSONObject()
        val secArr = JSONArray()
        spinSections.forEach { sec ->
            val s = JSONObject()
            s.put("coins", sec.coins)
            s.put("weight", sec.weight)
            secArr.put(s)
        }
        spinObj.put("sections", secArr)
        spinObj.put("requires_ad", spinRequiresAd)
        spinObj.put("max_spins_per_hour_per_user", maxSpinsPerHour)
        featObj.put("spin_wheel", spinObj)
        
        val tapObj = JSONObject()
        tapObj.put("coin_per_tap", coinPerTap)
        tapObj.put("taps_per_minute_limit", tapsPerMinuteLimit)
        featObj.put("tap", tapObj)
        
        val econObj = JSONObject()
        econObj.put("daily_coin_earning_cap", dailyCoinCap)
        econObj.put("monthly_coin_earning_cap", monthlyCoinCap)
        featObj.put("economy", econObj)
        
        root.put("features", featObj)
        return root.toString(2)
    }

    companion object {
        fun fromJsonString(jsonStr: String): RemoteConfigData {
            return try {
                val root = JSONObject(jsonStr)
                val appObj = root.optJSONObject("app") ?: JSONObject()
                val featObj = root.optJSONObject("features") ?: JSONObject()
                val refObj = appObj.optJSONObject("referral") ?: JSONObject()
                val chestObj = featObj.optJSONObject("golden_chest") ?: JSONObject()
                val spinObj = featObj.optJSONObject("spin_wheel") ?: JSONObject()
                val tapObj = featObj.optJSONObject("tap") ?: JSONObject()
                val econObj = featObj.optJSONObject("economy") ?: JSONObject()
                
                val spinSecs = mutableListOf<SpinSectionConfig>()
                val secArr = spinObj.optJSONArray("sections")
                if (secArr != null) {
                    for (i in 0 until secArr.length()) {
                        val obj = secArr.optJSONObject(i)
                        if (obj != null) {
                            spinSecs.add(
                                SpinSectionConfig(
                                    coins = obj.optInt("coins", 50),
                                    weight = obj.optInt("weight", 100)
                                )
                            )
                        }
                    }
                }
                if (spinSecs.isEmpty()) {
                    spinSecs.addAll(
                        listOf(
                            SpinSectionConfig(50, 300),
                            SpinSectionConfig(120, 250),
                            SpinSectionConfig(300, 100),
                            SpinSectionConfig(100, 200),
                            SpinSectionConfig(70, 149),
                            SpinSectionConfig(500, 1)
                        )
                    )
                }

                val chestCoins = mutableListOf<Int>()
                val cArr = chestObj.optJSONArray("default_rewards_coins")
                if (cArr != null) {
                    for (i in 0 until cArr.length()) {
                        chestCoins.add(cArr.optInt(i, 20))
                    }
                }
                if (chestCoins.isEmpty()) chestCoins.addAll(listOf(20, 35, 50))

                RemoteConfigData(
                    requireInternet = appObj.optBoolean("require_internet", true),
                    minWithdrawalUsd = appObj.optDouble("min_withdrawal_usd", 10.00),
                    perAdUserEarningUsd = appObj.optDouble("per_ad_user_earning_usd", 0.000005),
                    referralRewardUsd = refObj.optDouble("reward_usd", 0.025),
                    referralPendingToAvailableSeconds = refObj.optLong("pending_to_available_seconds", 1800L),
                    requiredCompletedReferralsToUnlockWithdrawals = refObj.optInt("required_completed_referrals_to_unlock_withdrawals", 2),
                    chestCooldownSeconds = chestObj.optLong("cooldown_seconds", 300L),
                    chestRequiresAd = chestObj.optBoolean("requires_ad_to_claim", false),
                    chestRewardsCoins = chestCoins,
                    spinSections = spinSecs,
                    spinRequiresAd = spinObj.optBoolean("requires_ad", true),
                    maxSpinsPerHour = spinObj.optInt("max_spins_per_hour_per_user", 12),
                    coinPerTap = tapObj.optInt("coin_per_tap", 1),
                    tapsPerMinuteLimit = tapObj.optInt("taps_per_minute_limit", 60),
                    dailyCoinCap = econObj.optLong("daily_coin_earning_cap", 20000L),
                    monthlyCoinCap = econObj.optLong("monthly_coin_earning_cap", 500000L)
                )
            } catch (e: Exception) {
                RemoteConfigData()
            }
        }
    }
}
