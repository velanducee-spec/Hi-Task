package com.example.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Casino
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.SpinSectionConfig
import com.example.data.models.SpinRecordEntity
import com.example.ui.theme.*
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun SpinWheelView(
    sections: List<SpinSectionConfig>,
    isSpinning: Boolean,
    onSpinRequested: () -> Unit,
    lastSpinResult: SpinRecordEntity?,
    onClearResultDialog: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val rotationAnim = remember { Animatable(0f) }

    val sliceColors = remember {
        listOf(
            WheelSector1,
            WheelSector2,
            WheelSector3,
            WheelSector4,
            WheelSector5,
            WheelSector6
        )
    }

    LaunchedEffect(lastSpinResult) {
        if (lastSpinResult != null) {
            val sectionCount = if (sections.isNotEmpty()) sections.size else 6
            val sweepAngle = 360f / sectionCount
            val targetSection = lastSpinResult.sectionIndex
            // Sector 0 angle starts at -90 deg. Top needle is at -90 deg.
            // To align targetSection to top pointer needle:
            val targetDegree = 360f * 5 - (targetSection * sweepAngle + sweepAngle / 2f)
            rotationAnim.animateTo(
                targetValue = targetDegree,
                animationSpec = tween(durationMillis = 3500, easing = FastOutSlowInEasing)
            )
        }
    }

    Card(
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        shape = RoundedCornerShape(20.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.3f)),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("spin_wheel_card")
    ) {
        Column(
            modifier = Modifier.padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(GoldPrimary.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Casino,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "Spin & Win Wheel",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "6 Sectors • Server Verified RNG",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                        )
                    }
                }

                Surface(
                    color = DarkSurfaceVariant,
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = "1 AD = 1 SPIN",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = GoldPrimary,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Wheel Canvas Container
            Box(
                modifier = Modifier.size(260.dp),
                contentAlignment = Alignment.Center
            ) {
                // Wheel Canvas
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val canvasSize = size.minDimension
                    val radius = canvasSize / 2f
                    val center = Offset(radius, radius)
                    val sectionCount = if (sections.isNotEmpty()) sections.size else 6
                    val sweepAngle = 360f / sectionCount

                    rotate(rotationAnim.value, center) {
                        for (i in 0 until sectionCount) {
                            val startAngle = i * sweepAngle - 90f
                            val color = sliceColors[i % sliceColors.size]
                            drawArc(
                                color = color,
                                startAngle = startAngle,
                                sweepAngle = sweepAngle,
                                useCenter = true,
                                topLeft = Offset(10f, 10f),
                                size = Size(canvasSize - 20f, canvasSize - 20f)
                            )

                            // Sector text
                            val coinsText = "${sections.getOrNull(i)?.coins ?: 50} C"
                            val midAngleRad = (startAngle + sweepAngle / 2f) * (PI / 180f)
                            val textRadius = radius * 0.65f
                            val textX = center.x + textRadius * cos(midAngleRad).toFloat()
                            val textY = center.y + textRadius * sin(midAngleRad).toFloat()

                            drawContext.canvas.nativeCanvas.apply {
                                val paint = android.graphics.Paint().apply {
                                    setColor(android.graphics.Color.WHITE)
                                    setTextSize(36f)
                                    setTypeface(android.graphics.Typeface.DEFAULT_BOLD)
                                    setTextAlign(android.graphics.Paint.Align.CENTER)
                                }
                                drawText(coinsText, textX, textY + 12f, paint)
                            }
                        }

                        // Outer ring border
                        drawCircle(
                            color = GoldPrimary,
                            radius = radius - 10f,
                            center = center,
                            style = Stroke(width = 8f)
                        )
                    }

                    // Center Cap
                    drawCircle(
                        color = DarkBackground,
                        radius = 28f,
                        center = center
                    )
                    drawCircle(
                        color = GoldPrimary,
                        radius = 20f,
                        center = center
                    )
                }

                // Top Pointer Needle
                Canvas(
                    modifier = Modifier
                        .size(32.dp)
                        .align(Alignment.TopCenter)
                        .offset(y = (-6).dp)
                ) {
                    val path = Path().apply {
                        moveTo(size.width / 2f, size.height)
                        lineTo(0f, 0f)
                        lineTo(size.width, 0f)
                        close()
                    }
                    drawPath(path, color = GoldPrimary)
                    drawPath(path, color = Color.Black, style = Stroke(width = 3f))
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Button(
                onClick = onSpinRequested,
                enabled = !isSpinning,
                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("spin_now_button")
            ) {
                if (isSpinning) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(22.dp),
                        color = Color.Black,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "Verifying Ad & Spinning...",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.PlayArrow,
                        contentDescription = null,
                        tint = Color.Black
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Watch Rewarded Ad to Spin",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }

    // Spin Win Reward Dialog Modal
    if (lastSpinResult != null) {
        AlertDialog(
            onDismissRequest = onClearResultDialog,
            confirmButton = {
                Button(
                    onClick = onClearResultDialog,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Collect Coins", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            title = {
                Text(
                    text = "🎉 You Won ${lastSpinResult.rewardCoins} Coins!",
                    fontWeight = FontWeight.Bold,
                    color = GoldPrimary
                )
            },
            text = {
                Column {
                    Text(
                        text = "Sector #${lastSpinResult.sectionIndex + 1} payout completed.",
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Transaction ID: ${lastSpinResult.id}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                    Text(
                        text = "Ad Receipt Token: ${lastSpinResult.adToken.take(16)}...",
                        fontSize = 10.sp,
                        color = TextDisabled
                    )
                }
            },
            containerColor = DarkSurface,
            shape = RoundedCornerShape(18.dp)
        )
    }
}
