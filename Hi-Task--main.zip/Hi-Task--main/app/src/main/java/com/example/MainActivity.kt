package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Assignment
import androidx.compose.material.icons.filled.Dashboard
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.AdSimModal
import com.example.ui.components.OfflineBlockOverlay
import com.example.ui.components.TopBar
import com.example.ui.screens.AdminConsoleScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.ReferralScreen
import com.example.ui.screens.TasksScreen
import com.example.ui.screens.WalletScreen
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.HiTaskTheme
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.MainViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            HiTaskTheme {
                val user by viewModel.userState.collectAsStateWithLifecycle()
                val config by viewModel.configState.collectAsStateWithLifecycle()
                val transactions by viewModel.transactionsState.collectAsStateWithLifecycle()
                val referrals by viewModel.referralsState.collectAsStateWithLifecycle()
                val withdrawals by viewModel.withdrawalsState.collectAsStateWithLifecycle()
                val adminLogs by viewModel.adminLogsState.collectAsStateWithLifecycle()

                val isOffline by viewModel.isOffline.collectAsStateWithLifecycle()
                val selectedTab by viewModel.currentTab.collectAsStateWithLifecycle()
                val showAdmin by viewModel.showAdminConsole.collectAsStateWithLifecycle()
                val showAdSim by viewModel.adManager.showAdSimModal.collectAsStateWithLifecycle()

                val lastChestTime by viewModel.lastChestClaimTime.collectAsStateWithLifecycle()
                val chestMsg by viewModel.chestMsg.collectAsStateWithLifecycle()

                val isSpinning by viewModel.isSpinning.collectAsStateWithLifecycle()
                val lastSpinResult by viewModel.lastSpinResult.collectAsStateWithLifecycle()

                val tapMsg by viewModel.tapMsg.collectAsStateWithLifecycle()
                val withdrawalMsg by viewModel.withdrawalMsg.collectAsStateWithLifecycle()

                Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
                    Scaffold(
                        topBar = {
                            TopBar(
                                user = user,
                                conversionRate = config.coinConversionRate,
                                isOffline = isOffline,
                                onToggleOffline = { viewModel.toggleOfflineStatus() },
                                onOpenAdmin = { viewModel.showAdminConsole.value = true }
                            )
                        },
                        bottomBar = {
                            if (!showAdmin) {
                                NavigationBar(
                                    containerColor = DarkSurface,
                                    contentColor = GoldPrimary,
                                    tonalElevation = 8.dp,
                                    modifier = Modifier
                                        .windowInsetsPadding(WindowInsets.navigationBars)
                                        .testTag("main_bottom_navigation")
                                ) {
                                    NavigationBarItem(
                                        selected = selectedTab == 0,
                                        onClick = { viewModel.currentTab.value = 0 },
                                        icon = { Icon(Icons.Default.Dashboard, contentDescription = "Dashboard") },
                                        label = { Text("Earn", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            selectedTextColor = GoldPrimary,
                                            indicatorColor = GoldPrimary,
                                            unselectedIconColor = TextSecondary,
                                            unselectedTextColor = TextSecondary
                                        ),
                                        modifier = Modifier.testTag("tab_earn")
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 1,
                                        onClick = { viewModel.currentTab.value = 1 },
                                        icon = { Icon(Icons.Default.Assignment, contentDescription = "Tasks") },
                                        label = { Text("Tasks", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            selectedTextColor = GoldPrimary,
                                            indicatorColor = GoldPrimary,
                                            unselectedIconColor = TextSecondary,
                                            unselectedTextColor = TextSecondary
                                        ),
                                        modifier = Modifier.testTag("tab_tasks")
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 2,
                                        onClick = { viewModel.currentTab.value = 2 },
                                        icon = { Icon(Icons.Default.Group, contentDescription = "Referrals") },
                                        label = { Text("Referrals", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            selectedTextColor = GoldPrimary,
                                            indicatorColor = GoldPrimary,
                                            unselectedIconColor = TextSecondary,
                                            unselectedTextColor = TextSecondary
                                        ),
                                        modifier = Modifier.testTag("tab_referrals")
                                    )
                                    NavigationBarItem(
                                        selected = selectedTab == 3,
                                        onClick = { viewModel.currentTab.value = 3 },
                                        icon = { Icon(Icons.Default.AccountBalanceWallet, contentDescription = "Wallet") },
                                        label = { Text("Wallet", fontWeight = FontWeight.Bold, fontSize = 11.sp) },
                                        colors = NavigationBarItemDefaults.colors(
                                            selectedIconColor = Color.Black,
                                            selectedTextColor = GoldPrimary,
                                            indicatorColor = GoldPrimary,
                                            unselectedIconColor = TextSecondary,
                                            unselectedTextColor = TextSecondary
                                        ),
                                        modifier = Modifier.testTag("tab_wallet")
                                    )
                                }
                            }
                        }
                    ) { innerPadding ->
                        Box(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                            if (showAdmin) {
                                AdminConsoleScreen(
                                    currentConfig = config,
                                    onSaveConfig = { newConfig, notes -> viewModel.saveRemoteConfig(newConfig, notes) },
                                    withdrawalsQueue = withdrawals,
                                    onUpdateWithdrawalStatus = { id, st, notes -> viewModel.updateWithdrawalStatus(id, st, notes) },
                                    adminLogs = adminLogs,
                                    onCloseAdmin = { viewModel.showAdminConsole.value = false }
                                )
                            } else {
                                when (selectedTab) {
                                    0 -> DashboardScreen(
                                        user = user,
                                        config = config,
                                        lastChestClaimTime = lastChestTime,
                                        onClaimChest = { viewModel.claimGoldenChest() },
                                        chestCooldownMsg = chestMsg,
                                        isSpinning = isSpinning,
                                        onSpinRequested = { viewModel.requestSpin(this@MainActivity) },
                                        lastSpinResult = lastSpinResult,
                                        onClearSpinResult = { viewModel.clearSpinResult() },
                                        onTapCoin = { viewModel.performTap() },
                                        tapMsg = tapMsg
                                    )
                                    1 -> TasksScreen(
                                        onClaimTaskReward = { coins -> viewModel.claimTaskReward(coins) }
                                    )
                                    2 -> ReferralScreen(
                                        user = user,
                                        referralsList = referrals,
                                        config = config,
                                        onSimulateRefereeTime = { id -> viewModel.simulateRefereeTime(id) },
                                        onAddMockReferral = { name -> viewModel.addMockReferral(name) }
                                    )
                                    3 -> WalletScreen(
                                        user = user,
                                        config = config,
                                        transactions = transactions,
                                        withdrawals = withdrawals,
                                        onSubmitWithdrawal = { amt, m, dest -> viewModel.submitWithdrawal(amt, m, dest) },
                                        withdrawalMsg = withdrawalMsg,
                                        onClearWdMsg = { viewModel.withdrawalMsg.value = null }
                                    )
                                }
                            }
                        }
                    }

                    // Simulated Rewarded Ad Player Modal Dialog
                    AdSimModal(
                        show = showAdSim,
                        onAdCompleted = { success ->
                            viewModel.adManager.completeSimulatedAd(success)
                        }
                    )

                    // Offline Blocking UI Overlay
                    OfflineBlockOverlay(
                        isOffline = isOffline,
                        onRetry = { viewModel.isOffline.value = false }
                    )
                }
            }
        }
    }
}
