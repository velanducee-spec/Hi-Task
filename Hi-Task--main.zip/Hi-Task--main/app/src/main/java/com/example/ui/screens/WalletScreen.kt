package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CurrencyBitcoin
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.RemoteConfigData
import com.example.data.models.TransactionEntity
import com.example.data.models.UserEntity
import com.example.data.models.WithdrawalEntity
import com.example.ui.theme.*

@Composable
fun WalletScreen(
    user: UserEntity,
    config: RemoteConfigData,
    transactions: List<TransactionEntity>,
    withdrawals: List<WithdrawalEntity>,
    onSubmitWithdrawal: (Double, String, String) -> Unit,
    withdrawalMsg: String?,
    onClearWdMsg: () -> Unit
) {
    var selectedMethod by remember { mutableStateOf("NAIRA_BANK") } // "NAIRA_BANK" or "CRYPTO_USDT"
    var bankNameInput by remember { mutableStateOf("First Bank Nigeria") }
    var accountNumberInput by remember { mutableStateOf("3098123456") }
    var accountNameInput by remember { mutableStateOf("John Doe") }
    var cryptoAddressInput by remember { mutableStateOf("TY8x9Z...TRC20Address") }
    var amountUsdInput by remember { mutableStateOf("10.00") }

    val walletUsd = user.walletCoins * config.coinConversionRate
    val hasMinBalance = walletUsd >= config.minWithdrawalUsd
    val hasRequiredRefs = user.completedReferralsCount >= config.requiredCompletedReferralsToUnlockWithdrawals
    val isKycVerified = user.kycStatus == "VERIFIED"
    val isFullyUnlocked = hasMinBalance && hasRequiredRefs && isKycVerified

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Balance Overview Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(GoldPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalanceWallet,
                                    contentDescription = null,
                                    tint = Color.Black,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = "Earnings Wallet",
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                )
                                Text(
                                    text = "1000 Coins = \$0.50 USD",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                )
                            }
                        }

                        Surface(
                            color = if (isFullyUnlocked) EmeraldGreen.copy(alpha = 0.2f) else RoseRed.copy(alpha = 0.2f),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Icon(
                                    imageVector = if (isFullyUnlocked) Icons.Default.CheckCircle else Icons.Default.Lock,
                                    contentDescription = null,
                                    tint = if (isFullyUnlocked) EmeraldGreen else RoseRed,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isFullyUnlocked) "PAYOUT READY" else "GATED",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isFullyUnlocked) EmeraldGreen else RoseRed
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(20.dp))

                    Text(
                        text = "\$${String.format("%.2f", walletUsd)} USD",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = GoldPrimary
                        )
                    )
                    Text(
                        text = "${user.walletCoins} Available Coins • ${user.walletPendingCoins} Pending Referral Coins",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )
                }
            }
        }

        // Withdrawal Qualification Checklist Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "Withdrawal Unlock Requirements",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    // Req 1: Min Balance $10
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (hasMinBalance) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (hasMinBalance) EmeraldGreen else RoseRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Wallet Balance >= \$${String.format("%.2f", config.minWithdrawalUsd)} USD (Current: \$${String.format("%.2f", walletUsd)})",
                            fontSize = 12.sp,
                            color = if (hasMinBalance) TextPrimary else TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Req 2: 2 Unlocked Referrals
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (hasRequiredRefs) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (hasRequiredRefs) EmeraldGreen else RoseRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Unlocked Referrals >= ${config.requiredCompletedReferralsToUnlockWithdrawals} (Current: ${user.completedReferralsCount})",
                            fontSize = 12.sp,
                            color = if (hasRequiredRefs) TextPrimary else TextSecondary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Req 3: KYC Status
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = if (isKycVerified) Icons.Default.CheckCircle else Icons.Default.Error,
                            contentDescription = null,
                            tint = if (isKycVerified) EmeraldGreen else RoseRed,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "KYC Identity Verification: ${user.kycStatus}",
                            fontSize = 12.sp,
                            color = if (isKycVerified) TextPrimary else TextSecondary
                        )
                    }
                }
            }
        }

        // Withdrawal Form Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("withdrawal_form_card")
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Submit Payout Request",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    // Method Selector Tabs
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(DarkSurfaceVariant)
                            .padding(4.dp)
                    ) {
                        Surface(
                            color = if (selectedMethod == "NAIRA_BANK") GoldPrimary else Color.Transparent,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("select_naira_bank")
                        ) {
                            TextButton(onClick = { selectedMethod = "NAIRA_BANK" }) {
                                Icon(
                                    imageVector = Icons.Default.AccountBalance,
                                    contentDescription = null,
                                    tint = if (selectedMethod == "NAIRA_BANK") Color.Black else TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Naira Bank",
                                    color = if (selectedMethod == "NAIRA_BANK") Color.Black else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }

                        Surface(
                            color = if (selectedMethod == "CRYPTO_USDT") GoldPrimary else Color.Transparent,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("select_crypto_usdt")
                        ) {
                            TextButton(onClick = { selectedMethod = "CRYPTO_USDT" }) {
                                Icon(
                                    imageVector = Icons.Default.CurrencyBitcoin,
                                    contentDescription = null,
                                    tint = if (selectedMethod == "CRYPTO_USDT") Color.Black else TextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Crypto (USDT)",
                                    color = if (selectedMethod == "CRYPTO_USDT") Color.Black else TextSecondary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Input Fields
                    OutlinedTextField(
                        value = amountUsdInput,
                        onValueChange = { amountUsdInput = it },
                        label = { Text("Amount (USD)", color = TextSecondary) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = DarkSurfaceBorder,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    if (selectedMethod == "NAIRA_BANK") {
                        OutlinedTextField(
                            value = bankNameInput,
                            onValueChange = { bankNameInput = it },
                            label = { Text("Bank Name", color = TextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = accountNumberInput,
                            onValueChange = { accountNumberInput = it },
                            label = { Text("Account Number", color = TextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = accountNameInput,
                            onValueChange = { accountNameInput = it },
                            label = { Text("Account Name", color = TextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    } else {
                        OutlinedTextField(
                            value = cryptoAddressInput,
                            onValueChange = { cryptoAddressInput = it },
                            label = { Text("USDT Wallet Address (TRC20 / BEP20)", color = TextSecondary) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedTextColor = TextPrimary,
                                unfocusedTextColor = TextPrimary
                            ),
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    if (withdrawalMsg != null) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = withdrawalMsg,
                            color = if (withdrawalMsg.startsWith("Success") || withdrawalMsg.startsWith("Withdrawal submitted")) EmeraldGreen else RoseRed,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(18.dp))

                    Button(
                        onClick = {
                            val amt = amountUsdInput.toDoubleOrNull() ?: 10.0
                            val dest = if (selectedMethod == "NAIRA_BANK") "$bankNameInput - $accountNumberInput ($accountNameInput)" else cryptoAddressInput
                            onSubmitWithdrawal(amt, selectedMethod, dest)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("submit_withdrawal_button")
                    ) {
                        Icon(imageVector = Icons.Default.Send, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Submit Withdrawal Request", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Transactions & Payouts History Header
        item {
            Text(
                text = "Recent Transactions & Withdrawal Status",
                style = MaterialTheme.typography.titleSmall.copy(
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
            )
        }

        items(withdrawals) { wd ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, DarkSurfaceBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Withdrawal (${wd.method})",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = wd.destinationInfo,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                        if (wd.adminNotes.isNotBlank()) {
                            Text(
                                text = "Note: ${wd.adminNotes}",
                                fontSize = 10.sp,
                                color = TextDisabled
                            )
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "-\$${String.format("%.2f", wd.amountUsd)}",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = RoseRed
                            )
                        )
                        Surface(
                            color = when (wd.status) {
                                "APPROVED", "PAID" -> EmeraldGreen.copy(alpha = 0.15f)
                                "REJECTED" -> RoseRed.copy(alpha = 0.15f)
                                else -> AmberAccent.copy(alpha = 0.15f)
                            },
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = wd.status,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (wd.status) {
                                    "APPROVED", "PAID" -> EmeraldGreen
                                    "REJECTED" -> RoseRed
                                    else -> AmberAccent
                                },
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        items(transactions) { tx ->
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = tx.type,
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = tx.metadata,
                            fontSize = 11.sp,
                            color = TextSecondary
                        )
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = if (tx.coins >= 0) "+${tx.coins} Coins" else "${tx.coins} Coins",
                            style = MaterialTheme.typography.labelMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (tx.coins >= 0) EmeraldGreen else RoseRed
                            )
                        )
                        Text(
                            text = "\$${String.format("%.4f", tx.usdValue)}",
                            fontSize = 10.sp,
                            color = TextDisabled
                        )
                    }
                }
            }
        }
    }
}
