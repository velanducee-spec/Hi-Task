package com.example.data.models

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "users")
data class UserEntity(
    @PrimaryKey val id: String = "user_default",
    val phone: String = "+2348012345678",
    val email: String = "earner@hitask.app",
    val walletCoins: Long = 2450L, // 1000 coins = $0.50 -> 2450 coins = $1.225
    val walletPendingCoins: Long = 50L, // Pending referral rewards in coin equivalent ($0.025 = 50 coins)
    val kycStatus: String = "VERIFIED", // "VERIFIED", "PENDING", "UNVERIFIED"
    val activeTimeSeconds: Long = 3600L,
    val completedReferralsCount: Int = 1, // Number of referrals that reached 1800s active time
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val type: String, // "GOLDEN_CHEST", "SPIN_WHEEL", "TAP", "REFERRAL_PENDING", "REFERRAL_UNLOCKED", "WITHDRAWAL", "TASK"
    val coins: Long,
    val usdValue: Double,
    val metadata: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "spins")
data class SpinRecordEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val sectionIndex: Int,
    val rewardCoins: Int,
    val adNetwork: String,
    val adUnit: String,
    val adToken: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "chest_claims")
data class ChestClaimEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val rewardCoins: Int,
    val claimedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "taps")
data class TapRecordEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val tapCount: Int,
    val rewardCoins: Int,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "referrals")
data class ReferralEntity(
    @PrimaryKey val id: String,
    val referrerUserId: String,
    val refereeUserId: String,
    val refereeName: String,
    val invitedAt: Long = System.currentTimeMillis(),
    val refereeUsageSeconds: Long = 0L,
    val status: String = "PENDING" // "PENDING", "AVAILABLE", "REJECTED"
)

@Entity(tableName = "withdrawals")
data class WithdrawalEntity(
    @PrimaryKey val id: String,
    val userId: String,
    val amountUsd: Double,
    val amountCoins: Long,
    val method: String, // "NAIRA_BANK", "CRYPTO_USDT"
    val destinationInfo: String,
    val status: String = "PENDING", // "PENDING", "APPROVED", "PAID", "REJECTED"
    val adminNotes: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "remote_config")
data class RemoteConfigEntity(
    @PrimaryKey val id: String = "default",
    val jsonConfig: String
)

@Entity(tableName = "admin_logs")
data class AdminLogEntity(
    @PrimaryKey val id: String,
    val actionType: String,
    val payload: String,
    val createdAt: Long = System.currentTimeMillis()
)
