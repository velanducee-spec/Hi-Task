package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.config.RemoteConfigData
import com.example.data.models.AdminLogEntity
import com.example.data.models.WithdrawalEntity
import com.example.ui.theme.*

@Composable
fun AdminConsoleScreen(
    currentConfig: RemoteConfigData,
    onSaveConfig: (RemoteConfigData, String) -> Unit,
    withdrawalsQueue: List<WithdrawalEntity>,
    onUpdateWithdrawalStatus: (String, String, String) -> Unit,
    adminLogs: List<AdminLogEntity>,
    onCloseAdmin: () -> Unit
) {
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Remote Config, 1: Econ Sim, 2: Withdrawal Queue, 3: Audit Logs

    var jsonInputText by remember(currentConfig) {
        mutableStateOf(currentConfig.toJsonString())
    }
    var configSaveMsg by remember { mutableStateOf<String?>(null) }

    // Econ Sim State
    var simulatedEcpm by remember { mutableStateOf("10.00") } // $10 eCPM = $0.01 per ad
    var simulatedDailyAds by remember { mutableStateOf("12") }
    var avgCoinsPerSpin by remember { mutableStateOf("110") }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Admin Header
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkSurface),
                shape = RoundedCornerShape(20.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AdminPanelSettings,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "Admin Console & Remote-Config",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Text(
                                text = "Server-Side Dynamic Parameters Control",
                                style = MaterialTheme.typography.labelSmall.copy(color = GoldPrimary)
                            )
                        }
                    }

                    IconButton(
                        onClick = onCloseAdmin,
                        modifier = Modifier.testTag("close_admin_button")
                    ) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                    }
                }
            }
        }

        // Navigation Tabs Bar
        item {
            ScrollableTabRow(
                selectedTabIndex = selectedTab,
                containerColor = DarkSurface,
                contentColor = GoldPrimary,
                edgePadding = 0.dp
            ) {
                Tab(
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    text = { Text("Remote Config", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    icon = { Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    text = { Text("Econ Simulator", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    icon = { Icon(Icons.Default.Calculate, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 2,
                    onClick = { selectedTab = 2 },
                    text = { Text("Payout Queue (${withdrawalsQueue.count { it.status == "PENDING" }})", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    icon = { Icon(Icons.Default.ListAlt, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
                Tab(
                    selected = selectedTab == 3,
                    onClick = { selectedTab = 3 },
                    text = { Text("Audit Logs", fontWeight = FontWeight.Bold, fontSize = 12.sp) },
                    icon = { Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(16.dp)) }
                )
            }
        }

        // TAB 0: Remote Config JSON Editor
        if (selectedTab == 0) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "JSON Remote Config Editor",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                            )
                            Button(
                                onClick = {
                                    val parsed = RemoteConfigData.fromJsonString(jsonInputText)
                                    onSaveConfig(parsed, "Admin updated remote config via JSON editor")
                                    configSaveMsg = "Config successfully deployed to server state!"
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.testTag("save_remote_config_button")
                            ) {
                                Icon(imageVector = Icons.Default.Save, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Save JSON", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }

                        if (configSaveMsg != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = configSaveMsg!!,
                                color = EmeraldGreen,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        OutlinedTextField(
                            value = jsonInputText,
                            onValueChange = {
                                jsonInputText = it
                                configSaveMsg = null
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(320.dp),
                            textStyle = MaterialTheme.typography.bodySmall.copy(
                                fontFamily = FontFamily.Monospace,
                                color = TextPrimary,
                                fontSize = 11.sp
                            ),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = DarkSurfaceBorder,
                                focusedContainerColor = DarkBackground,
                                unfocusedContainerColor = DarkBackground
                            )
                        )
                    }
                }
            }
        }

        // TAB 1: Economic Sustainability Simulator
        if (selectedTab == 1) {
            item {
                val ecpm = simulatedEcpm.toDoubleOrNull() ?: 10.0
                val revPerAdUsd = ecpm / 1000.0 // eCPM $10 = $0.01 per ad
                val dailyAds = simulatedDailyAds.toIntOrNull() ?: 12
                val spinAvgCoins = avgCoinsPerSpin.toIntOrNull() ?: 110
                val coinValUsd = currentConfig.coinConversionRate // 0.0005

                val userPayoutPerAdUsd = spinAvgCoins * coinValUsd // 110 * 0.0005 = $0.055
                val expectedAppDailyRevUsd = dailyAds * revPerAdUsd
                val expectedUserPayoutUsd = dailyAds * userPayoutPerAdUsd
                val profitMarginPercent = if (expectedAppDailyRevUsd > 0) ((expectedAppDailyRevUsd - expectedUserPayoutUsd) / expectedAppDailyRevUsd) * 100 else 0.0

                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(18.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Text(
                            text = "Ad Economics & Sustainability Calculator",
                            style = MaterialTheme.typography.titleSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                        )
                        Text(
                            text = "Simulate eCPM vs Payout ratios to ensure profit margins.",
                            style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        OutlinedTextField(
                            value = simulatedEcpm,
                            onValueChange = { simulatedEcpm = it },
                            label = { Text("AdMob eCPM (USD)", color = TextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = simulatedDailyAds,
                            onValueChange = { simulatedDailyAds = it },
                            label = { Text("Daily Ads Watched per User", color = TextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        OutlinedTextField(
                            value = avgCoinsPerSpin,
                            onValueChange = { avgCoinsPerSpin = it },
                            label = { Text("Average Coins awarded per Spin", color = TextSecondary) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )

                        Spacer(modifier = Modifier.height(16.dp))

                        Surface(
                            color = DarkSurfaceVariant,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("App Revenue per Ad:", fontSize = 12.sp, color = TextSecondary)
                                    Text("\$${String.format("%.4f", revPerAdUsd)} USD", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("User Payout per Spin:", fontSize = 12.sp, color = TextSecondary)
                                    Text("\$${String.format("%.4f", userPayoutPerAdUsd)} USD", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = GoldPrimary)
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Divider(color = DarkSurfaceBorder)
                                Spacer(modifier = Modifier.height(6.dp))
                                Row(
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text("Projected Profit Margin:", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextPrimary)
                                    Text(
                                        text = "${String.format("%.1f", profitMarginPercent)}%",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = if (profitMarginPercent >= 40.0) EmeraldGreen else RoseRed
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 2: Withdrawal Queue
        if (selectedTab == 2) {
            items(withdrawalsQueue) { wd ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            horizontalArrangement = Arrangement.SpaceBetween,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column {
                                Text("Withdrawal Request #${wd.id}", fontWeight = FontWeight.Bold, color = TextPrimary)
                                Text("Amount: \$${String.format("%.2f", wd.amountUsd)} USD (${wd.amountCoins} Coins)", color = GoldPrimary, fontWeight = FontWeight.SemiBold)
                                Text("Destination: ${wd.destinationInfo}", fontSize = 11.sp, color = TextSecondary)
                            }
                            Surface(
                                color = DarkSurfaceVariant,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(wd.status, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = GoldPrimary, modifier = Modifier.padding(4.dp))
                            }
                        }

                        if (wd.status == "PENDING") {
                            Spacer(modifier = Modifier.height(12.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Button(
                                    onClick = { onUpdateWithdrawalStatus(wd.id, "APPROVED", "Approved by Admin after fraud audit.") },
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = Color.Black)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                                Button(
                                    onClick = { onUpdateWithdrawalStatus(wd.id, "REJECTED", "Rejected: Suspicious activity detected.") },
                                    colors = ButtonDefaults.buttonColors(containerColor = RoseRed),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(imageVector = Icons.Default.Close, contentDescription = null, tint = Color.White)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reject", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 3: Audit Logs
        if (selectedTab == 3) {
            items(adminLogs) { log ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = DarkSurface),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(log.actionType, fontWeight = FontWeight.Bold, color = GoldPrimary, fontSize = 12.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(log.payload, fontSize = 11.sp, color = TextSecondary)
                    }
                }
            }
        }
    }
}
