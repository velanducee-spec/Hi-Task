package com.example.data.dao

import androidx.room.*
import com.example.data.models.*
import kotlinx.coroutines.flow.Flow

@Dao
interface UserDao {
    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    fun getUserFlow(userId: String = "user_default"): Flow<UserEntity?>

    @Query("SELECT * FROM users WHERE id = :userId LIMIT 1")
    suspend fun getUser(userId: String = "user_default"): UserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(user: UserEntity)

    @Query("UPDATE users SET walletCoins = walletCoins + :deltaCoins WHERE id = :userId")
    suspend fun addCoins(userId: String = "user_default", deltaCoins: Long)

    @Query("UPDATE users SET walletCoins = walletCoins - :deltaCoins WHERE id = :userId")
    suspend fun deductCoins(userId: String = "user_default", deltaCoins: Long)

    @Query("UPDATE users SET walletPendingCoins = walletPendingCoins + :deltaCoins WHERE id = :userId")
    suspend fun addPendingCoins(userId: String = "user_default", deltaCoins: Long)

    @Query("UPDATE users SET walletPendingCoins = walletPendingCoins - :deltaCoins WHERE id = :userId")
    suspend fun deductPendingCoins(userId: String = "user_default", deltaCoins: Long)

    @Query("UPDATE users SET completedReferralsCount = completedReferralsCount + 1 WHERE id = :userId")
    suspend fun incrementCompletedReferrals(userId: String = "user_default")

    @Query("UPDATE users SET activeTimeSeconds = activeTimeSeconds + :seconds WHERE id = :userId")
    suspend fun addActiveTime(userId: String = "user_default", seconds: Long)
}

@Dao
interface TransactionDao {
    @Query("SELECT * FROM transactions ORDER BY createdAt DESC")
    fun getAllTransactions(): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(transaction: TransactionEntity)
}

@Dao
interface SpinDao {
    @Query("SELECT * FROM spins ORDER BY createdAt DESC")
    fun getAllSpins(): Flow<List<SpinRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(spin: SpinRecordEntity)
}

@Dao
interface ChestDao {
    @Query("SELECT * FROM chest_claims ORDER BY claimedAt DESC LIMIT 1")
    suspend fun getLastChestClaim(): ChestClaimEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(claim: ChestClaimEntity)
}

@Dao
interface TapDao {
    @Query("SELECT SUM(tapCount) FROM taps WHERE createdAt >= :sinceTimestamp")
    suspend fun getTapsCountSince(sinceTimestamp: Long): Int?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(tap: TapRecordEntity)
}

@Dao
interface ReferralDao {
    @Query("SELECT * FROM referrals ORDER BY invitedAt DESC")
    fun getAllReferrals(): Flow<List<ReferralEntity>>

    @Query("SELECT * FROM referrals WHERE id = :id LIMIT 1")
    suspend fun getReferralById(id: String): ReferralEntity?

    @Query("SELECT COUNT(*) FROM referrals WHERE status = 'AVAILABLE'")
    suspend fun getUnlockedReferralsCount(): Int

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(referral: ReferralEntity)

    @Update
    suspend fun update(referral: ReferralEntity)
}

@Dao
interface WithdrawalDao {
    @Query("SELECT * FROM withdrawals ORDER BY createdAt DESC")
    fun getAllWithdrawals(): Flow<List<WithdrawalEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(withdrawal: WithdrawalEntity)

    @Query("UPDATE withdrawals SET status = :status, adminNotes = :notes WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, notes: String)
}

@Dao
interface RemoteConfigDao {
    @Query("SELECT * FROM remote_config WHERE id = 'default' LIMIT 1")
    fun getConfigFlow(): Flow<RemoteConfigEntity?>

    @Query("SELECT * FROM remote_config WHERE id = 'default' LIMIT 1")
    suspend fun getConfig(): RemoteConfigEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(config: RemoteConfigEntity)
}

@Dao
interface AdminLogDao {
    @Query("SELECT * FROM admin_logs ORDER BY createdAt DESC")
    fun getAllLogs(): Flow<List<AdminLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(log: AdminLogEntity)
}
