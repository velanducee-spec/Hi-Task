package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.*
import com.example.data.models.*

@Database(
    entities = [
        UserEntity::class,
        TransactionEntity::class,
        SpinRecordEntity::class,
        ChestClaimEntity::class,
        TapRecordEntity::class,
        ReferralEntity::class,
        WithdrawalEntity::class,
        RemoteConfigEntity::class,
        AdminLogEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun transactionDao(): TransactionDao
    abstract fun spinDao(): SpinDao
    abstract fun chestDao(): ChestDao
    abstract fun tapDao(): TapDao
    abstract fun referralDao(): ReferralDao
    abstract fun withdrawalDao(): WithdrawalDao
    abstract fun remoteConfigDao(): RemoteConfigDao
    abstract fun adminLogDao(): AdminLogDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "hitask_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
