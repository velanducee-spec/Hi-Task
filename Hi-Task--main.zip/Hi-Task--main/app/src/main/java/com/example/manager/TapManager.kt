package com.example.manager

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import com.example.data.AppDatabase
import com.example.data.models.TapRecordEntity
import com.example.data.models.TransactionEntity
import com.example.repository.HiTaskRepository
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.util.UUID

sealed class TapResult {
    data class Success(
        val rewardCoins: Int,
        val tapsRemainingThisMinute: Int,
        val serverSynced: Boolean = true
    ) : TapResult()

    data class RateLimited(val maxPerMinute: Int) : TapResult()
    object NoInternetConnection : TapResult()
}

/**
 * TapManager manages tap-to-earn frequency tracking, internet connectivity checks,
 * per-minute rate limit enforcement, and server synchronization for tap counts.
 */
class TapManager(
    private val context: Context,
    private val db: AppDatabase,
    private val repository: HiTaskRepository
) {

    private val appContext: Context =
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
            context.createAttributionContext("default")
        } else {
            context
        }

    /**
     * Checks if active network connectivity is present on the device.
     */
    fun isNetworkConnected(): Boolean {
        val connectivityManager = appContext.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
            ?: return false
        val activeNetwork = connectivityManager.activeNetwork ?: return false
        val capabilities = connectivityManager.getNetworkCapabilities(activeNetwork) ?: return false
        return capabilities.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    /**
     * Registers a tap after validating internet connection, checking per-minute rate limits,
     * and synchronizing tap count with the server.
     */
    suspend fun registerTap(isAppOfflineToggle: Boolean = false): TapResult = withContext(Dispatchers.IO) {
        // 1. Ensure taps only register if the device has an active internet connection (and app is online)
        if (isAppOfflineToggle || !isNetworkConnected()) {
            return@withContext TapResult.NoInternetConnection
        }

        val config = repository.getRemoteConfig()
        val now = System.currentTimeMillis()
        val minuteAgo = now - 60000L

        // 2. Track tap frequency and validate against per-minute limit
        val recentTapsCount = db.tapDao().getTapsCountSince(minuteAgo) ?: 0
        if (recentTapsCount >= config.tapsPerMinuteLimit) {
            return@withContext TapResult.RateLimited(config.tapsPerMinuteLimit)
        }

        // 3. Create tap record
        val reward = config.coinPerTap
        val tapId = "tap_" + UUID.randomUUID().toString().take(8)
        val tapRecord = TapRecordEntity(
            id = tapId,
            userId = "user_default",
            tapCount = 1,
            rewardCoins = reward,
            createdAt = now
        )

        // 4. Synchronize count with server
        val synced = syncTapWithServer(tapRecord, config.coinConversionRate)

        if (synced) {
            // Persist tap entry & award user coins locally after server sync confirmation
            db.tapDao().insert(tapRecord)
            db.userDao().addCoins("user_default", reward.toLong())

            db.transactionDao().insert(
                TransactionEntity(
                    id = tapId,
                    userId = "user_default",
                    type = "TAP",
                    coins = reward.toLong(),
                    usdValue = reward * config.coinConversionRate,
                    metadata = "Tap reward synchronized with server ledger"
                )
            )
        }

        val remainingThisMinute = config.tapsPerMinuteLimit - (recentTapsCount + 1)
        return@withContext TapResult.Success(
            rewardCoins = reward,
            tapsRemainingThisMinute = remainingThisMinute,
            serverSynced = synced
        )
    }

    /**
     * Simulates server synchronization endpoint for tap verification and anti-fraud check.
     */
    private suspend fun syncTapWithServer(
        tapRecord: TapRecordEntity,
        conversionRate: Double
    ): Boolean {
        // Simulates network payload synchronization with server
        delay(20L)
        return true
    }
}
