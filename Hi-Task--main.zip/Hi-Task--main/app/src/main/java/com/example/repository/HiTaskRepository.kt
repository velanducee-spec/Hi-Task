package com.example.repository

import com.example.config.RemoteConfigData
import com.example.data.AppDatabase
import com.example.data.models.*
import com.example.manager.TapResult
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import java.util.UUID
import kotlin.random.Random

class HiTaskRepository(private val db: AppDatabase) {

    val userFlow: Flow<UserEntity> = db.userDao().getUserFlow("user_default")
        .map { it ?: UserEntity() }

    val transactionsFlow: Flow<List<TransactionEntity>> = db.transactionDao().getAllTransactions()
    val referralsFlow: Flow<List<ReferralEntity>> = db.referralDao().getAllReferrals()
    val withdrawalsFlow: Flow<List<WithdrawalEntity>> = db.withdrawalDao().getAllWithdrawals()
    val adminLogsFlow: Flow<List<AdminLogEntity>> = db.adminLogDao().getAllLogs()
    val spinsFlow: Flow<List<SpinRecordEntity>> = db.spinDao().getAllSpins()

    val remoteConfigFlow: Flow<RemoteConfigData> = db.remoteConfigDao().getConfigFlow()
        .map { entity ->
            if (entity != null) RemoteConfigData.fromJsonString(entity.jsonConfig)
            else RemoteConfigData()
        }

    suspend fun initializeDefaults() {
        var user = db.userDao().getUser("user_default")
        if (user == null) {
            user = UserEntity(
                id = "user_default",
                phone = "+2348012345678",
                email = "earner@hitask.app",
                walletCoins = 2450L,
                walletPendingCoins = 50L,
                kycStatus = "VERIFIED",
                completedReferralsCount = 1
            )
            db.userDao().insertOrUpdate(user)
        }

        var configEntity = db.remoteConfigDao().getConfig()
        if (configEntity == null) {
            configEntity = RemoteConfigEntity(
                id = "default",
                jsonConfig = RemoteConfigData().toJsonString()
            )
            db.remoteConfigDao().insertOrUpdate(configEntity)
        }

        // Seed initial referrals if empty
        val existingRefs = db.referralDao().getUnlockedReferralsCount()
        db.referralDao().getAllReferrals()
        // If no referrals, seed 3 mock friends
        db.referralDao().insert(
            ReferralEntity(
                id = "ref_1",
                referrerUserId = "user_default",
                refereeUserId = "user_101",
                refereeName = "Alex M. (Completed)",
                invitedAt = System.currentTimeMillis() - 86400000L,
                refereeUsageSeconds = 1800L,
                status = "AVAILABLE"
            )
        )
        db.referralDao().insert(
            ReferralEntity(
                id = "ref_2",
                referrerUserId = "user_default",
                refereeUserId = "user_102",
                refereeName = "David O. (Active)",
                invitedAt = System.currentTimeMillis() - 43200000L,
                refereeUsageSeconds = 1150L, // 1150 / 1800s
                status = "PENDING"
            )
        )
        db.referralDao().insert(
            ReferralEntity(
                id = "ref_3",
                referrerUserId = "user_default",
                refereeUserId = "user_103",
                refereeName = "Sarah K. (New)",
                invitedAt = System.currentTimeMillis() - 7200000L,
                refereeUsageSeconds = 320L,
                status = "PENDING"
            )
        )
    }

    suspend fun getRemoteConfig(): RemoteConfigData {
        val entity = db.remoteConfigDao().getConfig()
        return if (entity != null) RemoteConfigData.fromJsonString(entity.jsonConfig)
        else RemoteConfigData()
    }

    suspend fun updateRemoteConfig(config: RemoteConfigData, adminNotes: String = "Admin config update") {
        val jsonStr = config.toJsonString()
        db.remoteConfigDao().insertOrUpdate(RemoteConfigEntity(id = "default", jsonConfig = jsonStr))
        db.adminLogDao().insert(
            AdminLogEntity(
                id = UUID.randomUUID().toString(),
                actionType = "REMOTE_CONFIG_UPDATE",
                payload = adminNotes
            )
        )
    }

    suspend fun getLastChestClaimTime(): Long {
        return db.chestDao().getLastChestClaim()?.claimedAt ?: 0L
    }

    sealed class ChestResult {
        data class Success(val rewardCoins: Int, val nextAvailableAt: Long) : ChestResult()
        data class Cooldown(val secondsRemaining: Long) : ChestResult()
    }

    suspend fun claimGoldenChest(): ChestResult {
        val config = getRemoteConfig()
        val lastClaim = getLastChestClaimTime()
        val now = System.currentTimeMillis()
        val cooldownMs = config.chestCooldownSeconds * 1000L
        val elapsed = now - lastClaim

        if (lastClaim > 0 && elapsed < cooldownMs) {
            val remainingSec = (cooldownMs - elapsed) / 1000L
            return ChestResult.Cooldown(remainingSec)
        }

        val rewardCoins = config.chestRewardsCoins.random()
        val claimId = UUID.randomUUID().toString()
        val claimEntity = ChestClaimEntity(id = claimId, userId = "user_default", rewardCoins = rewardCoins, claimedAt = now)
        db.chestDao().insert(claimEntity)

        db.userDao().addCoins("user_default", rewardCoins.toLong())

        val usdValue = rewardCoins * config.coinConversionRate
        db.transactionDao().insert(
            TransactionEntity(
                id = claimId,
                userId = "user_default",
                type = "GOLDEN_CHEST",
                coins = rewardCoins.toLong(),
                usdValue = usdValue,
                metadata = "Golden Chest rewards claim"
            )
        )

        return ChestResult.Success(rewardCoins, now + cooldownMs)
    }

    suspend fun performSpin(adToken: String = "token_admob_rewarded"): SpinRecordEntity {
        val config = getRemoteConfig()
        val sections = config.spinSections
        val totalWeight = sections.sumOf { it.weight }
        val randomVal = Random.nextInt(0, if (totalWeight > 0) totalWeight else 1)

        var currentSum = 0
        var selectedSectionIndex = 0
        var rewardCoins = sections.firstOrNull()?.coins ?: 50

        for (i in sections.indices) {
            currentSum += sections[i].weight
            if (randomVal < currentSum) {
                selectedSectionIndex = i
                rewardCoins = sections[i].coins
                break
            }
        }

        val spinId = "sp_" + UUID.randomUUID().toString().take(8)
        val spinRecord = SpinRecordEntity(
            id = spinId,
            userId = "user_default",
            sectionIndex = selectedSectionIndex,
            rewardCoins = rewardCoins,
            adNetwork = "AdMob",
            adUnit = "ca-app-pub-1621437411635895/5450122437",
            adToken = adToken
        )
        db.spinDao().insert(spinRecord)
        db.userDao().addCoins("user_default", rewardCoins.toLong())

        val usdVal = rewardCoins * config.coinConversionRate
        db.transactionDao().insert(
            TransactionEntity(
                id = spinId,
                userId = "user_default",
                type = "SPIN_WHEEL",
                coins = rewardCoins.toLong(),
                usdValue = usdVal,
                metadata = "Spin Wheel Sector #${selectedSectionIndex + 1} Reward ($rewardCoins Coins)"
            )
        )

        return spinRecord
    }

    suspend fun performTap(): TapResult {
        val config = getRemoteConfig()
        val now = System.currentTimeMillis()
        val minuteAgo = now - 60000L
        val recentTaps = db.tapDao().getTapsCountSince(minuteAgo) ?: 0

        if (recentTaps >= config.tapsPerMinuteLimit) {
            return TapResult.RateLimited(config.tapsPerMinuteLimit)
        }

        val reward = config.coinPerTap
        val tapId = "tap_" + UUID.randomUUID().toString().take(8)
        db.tapDao().insert(
            TapRecordEntity(
                id = tapId,
                userId = "user_default",
                tapCount = 1,
                rewardCoins = reward,
                createdAt = now
            )
        )
        db.userDao().addCoins("user_default", reward.toLong())

        val remaining = config.tapsPerMinuteLimit - (recentTaps + 1)
        return TapResult.Success(reward, remaining)
    }

    suspend fun simulateRefereeProgress(referralId: String, deltaSeconds: Long = 300L) {
        val ref = db.referralDao().getReferralById(referralId) ?: return
        val config = getRemoteConfig()
        val newTime = ref.refereeUsageSeconds + deltaSeconds
        val threshold = config.referralPendingToAvailableSeconds // 1800s

        if (newTime >= threshold && ref.status == "PENDING") {
            val updated = ref.copy(refereeUsageSeconds = threshold, status = "AVAILABLE")
            db.referralDao().update(updated)
            db.userDao().incrementCompletedReferrals("user_default")

            // Grant $0.025 referral reward in coins (50 coins)
            val coinsReward = (config.referralRewardUsd / config.coinConversionRate).toLong()
            db.userDao().addCoins("user_default", coinsReward)
            db.userDao().deductPendingCoins("user_default", coinsReward)

            db.transactionDao().insert(
                TransactionEntity(
                    id = "ref_tx_" + UUID.randomUUID().toString().take(8),
                    userId = "user_default",
                    type = "REFERRAL_UNLOCKED",
                    coins = coinsReward,
                    usdValue = config.referralRewardUsd,
                    metadata = "Referral ${ref.refereeName} completed 30 minutes active usage requirement!"
                )
            )
        } else {
            val updated = ref.copy(refereeUsageSeconds = newTime)
            db.referralDao().update(updated)
        }
    }

    suspend fun addSimulatedReferral(friendName: String) {
        val refId = "ref_" + System.currentTimeMillis()
        val config = getRemoteConfig()
        db.referralDao().insert(
            ReferralEntity(
                id = refId,
                referrerUserId = "user_default",
                refereeUserId = "user_" + Random.nextInt(200, 999),
                refereeName = friendName,
                invitedAt = System.currentTimeMillis(),
                refereeUsageSeconds = 0L,
                status = "PENDING"
            )
        )
        val coinsReward = (config.referralRewardUsd / config.coinConversionRate).toLong()
        db.userDao().addPendingCoins("user_default", coinsReward)
    }

    sealed class WithdrawalResult {
        data class Success(val withdrawalId: String) : WithdrawalResult()
        data class Failure(val reason: String) : WithdrawalResult()
    }

    suspend fun submitWithdrawal(
        amountUsd: Double,
        method: String,
        destinationInfo: String
    ): WithdrawalResult {
        val user = db.userDao().getUser("user_default") ?: return WithdrawalResult.Failure("User not found")
        val config = getRemoteConfig()

        if (user.kycStatus != "VERIFIED") {
            return WithdrawalResult.Failure("KYC verification is required before withdrawing funds.")
        }

        if (user.completedReferralsCount < config.requiredCompletedReferralsToUnlockWithdrawals) {
            return WithdrawalResult.Failure("You need at least ${config.requiredCompletedReferralsToUnlockWithdrawals} active referrals with 30-min usage to unlock withdrawals (Current: ${user.completedReferralsCount}).")
        }

        if (amountUsd < config.minWithdrawalUsd) {
            return WithdrawalResult.Failure("Minimum withdrawal amount is \$${String.format("%.2f", config.minWithdrawalUsd)} USD.")
        }

        val requiredCoins = (amountUsd / config.coinConversionRate).toLong()
        if (user.walletCoins < requiredCoins) {
            return WithdrawalResult.Failure("Insufficient wallet balance. You need $requiredCoins coins (\$${String.format("%.2f", amountUsd)}).")
        }

        db.userDao().deductCoins("user_default", requiredCoins)

        val wdId = "wd_" + UUID.randomUUID().toString().take(8)
        db.withdrawalDao().insert(
            WithdrawalEntity(
                id = wdId,
                userId = "user_default",
                amountUsd = amountUsd,
                amountCoins = requiredCoins,
                method = method,
                destinationInfo = destinationInfo,
                status = "PENDING",
                adminNotes = "Submitted and queued for anti-fraud review"
            )
        )

        db.transactionDao().insert(
            TransactionEntity(
                id = wdId,
                userId = "user_default",
                type = "WITHDRAWAL",
                coins = -requiredCoins,
                usdValue = -amountUsd,
                metadata = "Withdrawal request to $method ($destinationInfo)"
            )
        )

        return WithdrawalResult.Success(wdId)
    }

    suspend fun updateWithdrawalStatus(withdrawalId: String, newStatus: String, adminNotes: String) {
        db.withdrawalDao().updateStatus(withdrawalId, newStatus, adminNotes)
        db.adminLogDao().insert(
            AdminLogEntity(
                id = UUID.randomUUID().toString(),
                actionType = "WITHDRAWAL_STATUS_UPDATE",
                payload = "Withdrawal $withdrawalId set to $newStatus. Notes: $adminNotes"
            )
        )
    }
}
