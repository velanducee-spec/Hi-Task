package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ads.AdManager
import com.example.config.RemoteConfigData
import com.example.data.AppDatabase
import com.example.data.models.*
import com.example.manager.TapManager
import com.example.manager.TapResult
import com.example.repository.HiTaskRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    val repository: HiTaskRepository
    val adManager: AdManager
    val tapManager: TapManager

    val userState = MutableStateFlow(UserEntity())
    val configState = MutableStateFlow(RemoteConfigData())
    val transactionsState = MutableStateFlow<List<TransactionEntity>>(emptyList())
    val referralsState = MutableStateFlow<List<ReferralEntity>>(emptyList())
    val withdrawalsState = MutableStateFlow<List<WithdrawalEntity>>(emptyList())
    val adminLogsState = MutableStateFlow<List<AdminLogEntity>>(emptyList())
    val spinsState = MutableStateFlow<List<SpinRecordEntity>>(emptyList())

    val isOffline = MutableStateFlow(false)
    val currentTab = MutableStateFlow(0) // 0: Dashboard, 1: Tasks, 2: Referrals, 3: Wallet, 4: Admin
    val showAdminConsole = MutableStateFlow(false)

    val lastChestClaimTime = MutableStateFlow(0L)
    val chestMsg = MutableStateFlow<String?>(null)

    val isSpinning = MutableStateFlow(false)
    val lastSpinResult = MutableStateFlow<SpinRecordEntity?>(null)

    val tapMsg = MutableStateFlow<String?>(null)
    val withdrawalMsg = MutableStateFlow<String?>(null)

    init {
        val db = AppDatabase.getDatabase(application)
        repository = HiTaskRepository(db)
        adManager = AdManager(application)
        tapManager = TapManager(application, db, repository)

        viewModelScope.launch {
            repository.initializeDefaults()
            lastChestClaimTime.value = repository.getLastChestClaimTime()
        }

        viewModelScope.launch {
            repository.userFlow.collectLatest { userState.value = it }
        }

        viewModelScope.launch {
            repository.remoteConfigFlow.collectLatest { configState.value = it }
        }

        viewModelScope.launch {
            repository.transactionsFlow.collectLatest { transactionsState.value = it }
        }

        viewModelScope.launch {
            repository.referralsFlow.collectLatest { referralsState.value = it }
        }

        viewModelScope.launch {
            repository.withdrawalsFlow.collectLatest { withdrawalsState.value = it }
        }

        viewModelScope.launch {
            repository.adminLogsFlow.collectLatest { adminLogsState.value = it }
        }

        viewModelScope.launch {
            repository.spinsFlow.collectLatest { spinsState.value = it }
        }
    }

    fun toggleOfflineStatus() {
        isOffline.value = !isOffline.value
    }

    fun claimGoldenChest() {
        if (isOffline.value) return
        viewModelScope.launch {
            val res = repository.claimGoldenChest()
            when (res) {
                is HiTaskRepository.ChestResult.Success -> {
                    lastChestClaimTime.value = System.currentTimeMillis()
                    chestMsg.value = "Claimed +${res.rewardCoins} Coins!"
                }
                is HiTaskRepository.ChestResult.Cooldown -> {
                    chestMsg.value = "Cooldown active: ${res.secondsRemaining}s remaining"
                }
            }
        }
    }

    fun requestSpin(activity: android.app.Activity) {
        if (isOffline.value) return
        if (isSpinning.value) return

        isSpinning.value = true
        chestMsg.value = null

        adManager.showRewardedAd(activity) { success, token ->
            if (success) {
                viewModelScope.launch {
                    val result = repository.performSpin(adToken = token)
                    lastSpinResult.value = result
                    isSpinning.value = false
                }
            } else {
                isSpinning.value = false
            }
        }
    }

    fun clearSpinResult() {
        lastSpinResult.value = null
    }

    fun performTap() {
        viewModelScope.launch {
            val res = tapManager.registerTap(isOffline.value)
            when (res) {
                is TapResult.Success -> {
                    tapMsg.value = "+${res.rewardCoins} Coin! (${res.tapsRemainingThisMinute} left this min)"
                }
                is TapResult.RateLimited -> {
                    tapMsg.value = "Rate Limit Reached! Max ${res.maxPerMinute} taps/min."
                }
                is TapResult.NoInternetConnection -> {
                    tapMsg.value = "Offline / No Internet Connection! Tap disabled."
                }
            }
        }
    }

    fun claimTaskReward(coins: Int) {
        if (isOffline.value) return
        viewModelScope.launch {
            repository.userFlow
            val db = AppDatabase.getDatabase(getApplication())
            db.userDao().addCoins("user_default", coins.toLong())
            db.transactionDao().insert(
                TransactionEntity(
                    id = "task_tx_" + java.util.UUID.randomUUID().toString().take(8),
                    userId = "user_default",
                    type = "TASK",
                    coins = coins.toLong(),
                    usdValue = coins * configState.value.coinConversionRate,
                    metadata = "Task completed reward"
                )
            )
        }
    }

    fun simulateRefereeTime(referralId: String) {
        if (isOffline.value) return
        viewModelScope.launch {
            repository.simulateRefereeProgress(referralId, deltaSeconds = 300L)
        }
    }

    fun addMockReferral(name: String) {
        if (isOffline.value) return
        viewModelScope.launch {
            repository.addSimulatedReferral(name)
        }
    }

    fun submitWithdrawal(amountUsd: Double, method: String, destinationInfo: String) {
        if (isOffline.value) return
        viewModelScope.launch {
            val res = repository.submitWithdrawal(amountUsd, method, destinationInfo)
            when (res) {
                is HiTaskRepository.WithdrawalResult.Success -> {
                    withdrawalMsg.value = "Withdrawal submitted successfully! ID: ${res.withdrawalId}"
                }
                is HiTaskRepository.WithdrawalResult.Failure -> {
                    withdrawalMsg.value = res.reason
                }
            }
        }
    }

    fun saveRemoteConfig(newConfig: RemoteConfigData, notes: String) {
        viewModelScope.launch {
            repository.updateRemoteConfig(newConfig, notes)
        }
    }

    fun updateWithdrawalStatus(id: String, status: String, notes: String) {
        viewModelScope.launch {
            repository.updateWithdrawalStatus(id, status, notes)
        }
    }
}
