package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFFFD700)
val GoldSecondary = Color(0xFFFFB700)
val AmberAccent = Color(0xFFFF9800)
val NeonCyan = Color(0xFF00F0FF)
val EmeraldGreen = Color(0xFF10B981)
val RoseRed = Color(0xFFF43F5E)

val DarkBackground = Color(0xFF0B0F19)
val DarkSurface = Color(0xFF151C2C)
val DarkSurfaceVariant = Color(0xFF1E293B)
val DarkSurfaceBorder = Color(0xFF334155)

val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val TextDisabled = Color(0xFF64748B)

val WheelSector1 = Color(0xFFFF4757) // Red
val WheelSector2 = Color(0xFF2ED573) // Green
val WheelSector3 = Color(0xFFFFA502) // Gold
val WheelSector4 = Color(0xFF1E90FF) // Blue
val WheelSector5 = Color(0xFF9B59B6) // Purple
val WheelSector6 = Color(0xFFFF7F50) // Coral
